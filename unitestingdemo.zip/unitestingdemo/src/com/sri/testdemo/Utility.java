package com.sri.testdemo;

public class Utility
{
    public boolean isElementExist(int[] x,int element)
    {
    	for(int i=0;i<x.length;i++)
    		if(x[i]==element)
    			return true;
    		return false;
    }


public boolean isEven(int n) {

return n%2 == 0;

}
}