package com.sri.unitest.demo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import com.sri.testdemo.Calculator;
class CalculatorTest {
	
    static Calculator c = null;
	//@BeforeEach
    @BeforeAll
	static void setUp() throws Exception
	{
		c = new Calculator();
    }

	//@AfterEach
    @AfterAll
	static void tearDown() throws Exception
	{
		c = null;
	}
	
	@Test
	void sumtest() 
	{
		assertEquals(150,c.sum(10,20,30,40,50));
	}
	@Test
	public void squareTest()
	{
		assertEquals(100,c.square(10));
	}
	
	@Test
	public void powerTest()
	{
		assertEquals(125,c.power(5, 3));
	}

}
