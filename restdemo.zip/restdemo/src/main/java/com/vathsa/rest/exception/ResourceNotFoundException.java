package com.vathsa.rest.exception;
public class ResourceNotFoundException extends RuntimeException
{
    
}
