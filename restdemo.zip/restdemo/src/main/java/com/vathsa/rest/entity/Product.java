package com.vathsa.rest.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Column;

@Entity
public class Product 
{
	@Id
	@Column(name="pro_id")
	private int productId;
	
	@Column(name="pro_name")
	private String productName;
	
	@Column(name="pro_cost")
	private double productCost;
	
	@Column(name="pro_count")
	private int productCount;
	
	public Product()  {}

	public Product(int productId, String productName, double productCost, int productCount) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCost = productCost;
		this.productCount = productCount;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductCost() {
		return productCost;
	}

	public void setProductCost(double productCost) {
		this.productCost = productCost;
	}

	public int getProductCount() {
		return productCount;
	}

	public void setProductCount(int productCount) {
		this.productCount = productCount;
	}
    
		

}
