package com.vathsa.rest.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.vathsa.rest.entity.Product;
import com.vathsa.rest.exception.ResourceNotModifiedException;
import com.vathsa.rest.service.ProductService;
@CrossOrigin(origins= {"http://localhost:4200"})
@RequestMapping("/product")
@RestController
public class ProductController 
{
	@Autowired
	ProductService productService;
	
	@GetMapping(value="/",produces="application/json")
	public ResponseEntity<List<Product>> getAllProducts()
	{
		List<Product> plist = productService.getAllProducts(); 
		if(plist.size()!=0)
			return new ResponseEntity<List<Product>>(plist,HttpStatus.OK);
		return new ResponseEntity<List<Product>>(plist,HttpStatus.NOT_FOUND);		
	}
	
	@GetMapping(value="/productId",produces="application/json")
	public ResponseEntity<Product> getProductByProductId(@PathVariable int productId)
	{
		Product p = productService.getProductByProductId(productId);
		if(p!=null)
			return new ResponseEntity<Product>(p,HttpStatus.OK);
		return new ResponseEntity<Product>(p,HttpStatus.NOT_FOUND);
	}
	
	@PostMapping(value="/",consumes="application/json")
	public HttpStatus insertProduct(@RequestBody Product product)
	{
		productService.insertOrModifyProduct(product);
		return HttpStatus.OK;
	}
	
	@PutMapping(value="/",consumes="application/json")
	public HttpStatus modifyProduct(@RequestBody Product product)
	{
		productService.insertOrModifyProduct(product);
		return HttpStatus.OK;
	}
	
	@DeleteMapping("/{productId}")
	public HttpStatus deleteProduct(@PathVariable int productId)
	{
		if(productService.deleteProductByProductId(productId))
			return HttpStatus.OK;
		return HttpStatus.NOT_FOUND;
	}
	
	@ExceptionHandler(ResourceNotModifiedException.class)
	public HttpStatus notModifiedExceptionHandler()
	{
		return HttpStatus.NOT_MODIFIED;
	}
	


}
