package com.vathsa.rest.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.vathsa.rest.entity.Train;

public interface TrainRepository extends JpaRepository<Train,Integer>
{
	

}
