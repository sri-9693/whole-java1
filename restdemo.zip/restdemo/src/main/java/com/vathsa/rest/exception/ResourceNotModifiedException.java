package com.vathsa.rest.exception;

public class ResourceNotModifiedException extends RuntimeException
{
	

}
