package com.vathsa.rest.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.vathsa.rest.entity.Passengers;
import com.vathsa.rest.entity.Train;

public interface PassengersRepository extends JpaRepository<Passengers,Integer>
{

	
}
