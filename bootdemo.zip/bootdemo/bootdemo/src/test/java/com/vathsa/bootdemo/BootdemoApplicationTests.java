package com.vathsa.bootdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
