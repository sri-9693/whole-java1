package com.vathsa.bootdemo;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import com.vathsa.bootdemo.entity.Employee;
import com.vathsa.bootdemo.beans.Person;
import com.vathsa.bootdemo.entity.Book;
import com.vathsa.bootdemo.entity.Department;
import com.vathsa.bootdemo.repository.BookRepository;
import com.vathsa.bootdemo.repository.DepartmentRepository;
import com.vathsa.bootdemo.service.DepartmentService;
@SpringBootApplication
public class BootdemoApplication 
{
	public static void main(String[] args) 
	{

	 ConfigurableApplicationContext container = SpringApplication.run(BootdemoApplication.class,args);
	 DepartmentService ds = container.getBean(DepartmentService.class);
	 Department d1= ds.getDepartmentByDepartmentId(20);
	 System.out.println(d1.getDepartmentNo()+" "+d1.getDepartmentName()+" "+d1.getLocation());
	 for(Employee e : d1.getEmployees())
		 System.out.println(e.getEmployeeId()+" "+e.getEmployeeName()+"  "+
	                           e.getSalary());
		
		} 
}




//List<Book> books = bookRepository.findAll();
//for(Book b : books)
//	System.out.println(b.getBookId()+" "+b.getBookTitle()+" "+
//  b.getBookAuthor()+" "+b.getBookCategory()
//  +" "+b.getBookPrice()+" "+b.getAvailabeCopies());


// Optional<Book> findByBookTitle(String bookTitle);
//if(b.isPresent())
//{
//	Book b1 = b.get();
//	System.out.println(b1.getBookTitle()+" "+b1.getBookCategory()+" "+
//                   b1.getBookAuthor()+" "+b1.getBookPrice()+" "+
//			b1.getAvailabeCopies());
//}
//else
//{
//	System.out.println("Book doesn't exist");
//}


//List<Book> blist = bookRepository.findByBookCategory("java");
//for(Book b : blist)
//{
//	System.out.println(b.getBookId()+" "+b.getBookTitle()+" "+
//			  b.getBookAuthor()+" "+b.getBookCategory()
//			  +" "+b.getBookPrice()+" "+b.getAvailabeCopies());
//}




//Optional<Book> b = bookRepository.findByBookPrice(800);
//if(b.isPresent())
//{
//	Book b1 = b.get();
//	System.out.println(b1.getBookId()+" "+b1.getBookAuthor()+" "+
//	      b1.getBookCategory()+" "+b1.getBookPrice()+" "+b1.getBookTitle());
//}
//else
//{
//	System.out.println("Book doesn't exist");
//}



//DepartmentRepository dr = container.getBean(DepartmentRepository.class);
//Optional<Department> d = dr.findById(20);
//if(d.isPresent())
//{
//	Department d1 = d.get();
//	System.out.println(d1.getDepartmentNo()+" "+d1.getDepartmentName()
//	+" "+d1.getLocation());
//   for(Employee e : d1.getEmployees())
//	   System.out.println(e.getEmployeeId()+" "+e.getEmployeeName()+" "+
//         e.getSalary());




//DepartmentService ds = container.getBean(DepartmentService.class);
//Department d1= ds.getDepartmentByDepartmentId(20);
//System.out.println(d1.getDepartmentNo()+" "+d1.getDepartmentName());
//for(Employee e : d1.getEmployees())
//	 System.out.println(e.getEmployeeId()+" "+e.getEmployeeName()+"  "+
//                          e.getSalary());


