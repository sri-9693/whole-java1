package com.vathsa.bootdemo.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.vathsa.bootdemo.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department,Integer>
{
   
}
