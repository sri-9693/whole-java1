package com.vathsa.mavenDemo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.vathsa.model.Calculator;

class TestCalculator {

	Calculator c = null;
	
	@BeforeEach
	void setUp() throws Exception
	{
		c = new Calculator();
	}
	

	@AfterEach
	void tearDown() throws Exception 
	{
		c = null;
	}

	@Test
	void testSquare() 
	{
		assertEquals(144,c.square(12));
	}
	
	@Test
	void testSum() 
	{
		assertEquals(33,c.sum(8,25));
	}
	
	@Test
	void testPower() 
	{
		assertEquals(8,c.power(2,3));
	}
	
}
